package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class PesquisaController {
    
    private Stage stagePesquisa;
    RadioButton botaoLinguagensSelcionado;
    ToggleGroup tgLinguagens =  new ToggleGroup();
    ToggleButton botaoSOSelecionado;
    ToggleGroup tgSitemaOperacional =  new ToggleGroup();

    @FXML
    private Button btnSubmeterPesquisa;

      @FXML
    private Button btnFechar;

    @FXML
    private CheckBox chkGostaProgramar;

    @FXML
    private CheckBox chkProgramaTodosDias;

    @FXML
    private RadioButton rbC;

    @FXML
    private RadioButton rbJava;

    @FXML
    private RadioButton rbPython;

    @FXML
    private ToggleButton tbLinux;

    @FXML
    private ToggleButton tbMac;

    @FXML
    private ToggleButton tbWindows;

    @FXML
    private TextField txtNomeCompleto;

    @FXML
    void onClickBtnSubmeterPesquisa(ActionEvent event) {
        System.out.println("\n\n");
        if(!txtNomeCompleto.getText().isEmpty()){
        System.out.println("Nome completo: " +
        txtNomeCompleto.getText());
    }
        botaoSOSelecionado = (ToggleButton)
                tgSitemaOperacional.getSelectedToggle();
        System.out.println(botaoSOSelecionado == null ? "Nao selecionado" : botaoSOSelecionado.getText());
        
        botaoLinguagensSelcionado = (RadioButton) tgLinguagens.getSelectedToggle();
        
        System.out.println("Linguagem e programacao preferida");
        if(botaoLinguagensSelcionado != null){
        System.out.print(botaoLinguagensSelcionado.getText());
        }else{            
                System.out.println("Nao selecionao");
        }
        
           System.out.print("Programa todo dia?");
           System.out.println(chkProgramaTodosDias.isSelected() == true ? "Sim" : "Nao");
                      System.out.print("Gosta de programar?");

           if(chkGostaProgramar.isSelected()){
               System.out.println("Sim");
            }else{
                System.out.println("Nao");

           }
    }
    @FXML
    void onClickBtnFechar(ActionEvent event) {
    if(stagePesquisa != null)
        stagePesquisa.close();
    }

    void setStage(Stage novaTela) {
        this.stagePesquisa = novaTela;
    }
     //b
    void ajustarElementosJanela(){
        System.out.println("Chamou a abertura de janela");
        tgLinguagens.getToggles().addAll(rbJava, rbPython, rbC);
        
    }
} 
