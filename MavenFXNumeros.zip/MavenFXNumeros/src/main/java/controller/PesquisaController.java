package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;

public class PesquisaController {

    @FXML
    private Button btnSubmeterPesquisa;

    @FXML
    private CheckBox chkGostaDeProgramar;

    @FXML
    private CheckBox chkProgramaTodoOsDias;

    @FXML
    private Label lblLinguagemDeProgramacaoPreferida;

    @FXML
    private Label lblNomCompleto;

    @FXML
    private Label lblPesquisaSobreProgramacao;

    @FXML
    private Label lblSistemaOperacionalQueUtiliza;

    @FXML
    private RadioButton rbC;

    @FXML
    private RadioButton rbJava;

    @FXML
    private RadioButton rbPython;

    @FXML
    private ToggleButton tbLinux;

    @FXML
    private ToggleButton tbMac;

    @FXML
    private ToggleButton tbWindows;

    @FXML
    private TextField textNomeCompleto;

    @FXML
    void onClickSubmeterPesquisa(ActionEvent event) {

    }

}
